
<!doctype html>
<html lang="en">
<title>Ondrovy školičky</title>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin="" />
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>
</head>
    <style>
      .navbar-marg
      {
        margin-bottom: 25px;
      }
      .uprostred
      {
        text-align: center;
      }
      
      #map { height: 520px; }
    </style>
       
    <body>
    <script>
        $(document).ready(function() {
            $('#skoly').DataTable();
        });
    </script>
        <div class= "container">
        <br /><br /><br /> 
        <h1 class="uprostred">Školy Školy Školy</h1>
        <br /><br /><br /> 
        <div id="map"></div>
        <br /><br /><br /> 
        <div class="table-responsive">  
           <table id="skoly" class="table display table-bordered">  
                <thead>
                    <tr>  
                         <th>Počet přijatých</th>  
                         <th>Rok</th>  
                         <th>Název školy</th>  
                         <th>Obor</th>   
                    </tr>  
                </thead>
                <tbody>
               <?php  
           
                foreach($vypis_skoly as $row)  
                {  
               ?>  
               
                <tr>  
                     <td><?php echo $row->pocet; ?></td>  
                     <td><?php echo $row->rok; ?></td>  
                     <td><?php echo $row->nazev_skoly; ?></td>
                     <td><?php echo $row->nazev_oboru; ?></td>
                       
                </tr>  
           <?php       
                }  
              
           ?>  
           </tbody>
           </table>  
      </div>  
    </body>
     <script>
          <?php
                $js_array = json_encode($vypis_skoly);
                echo "var skoly = " . $js_array . ";\n";
                ?>
     var map = L.map('map').setView([49.032687, 17.643536], 12);
     L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
     attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
     })
     .addTo(map);
     for (let i = 0; i < skoly.length; i++) {
                    L.marker(
                            L.latLng(
                                parseFloat(skoly[i].geo_lat),
                                parseFloat(skoly[i].geo_long)
                            )
                        ).addTo(map)
                        .bindPopup(skoly[i].nazev_skoly);
                }
     </script>
     
</html>